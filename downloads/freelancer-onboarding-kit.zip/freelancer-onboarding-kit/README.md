# Freelancer Client Onboarding Kit

Welcome! This kit gives you everything you need to onboard new freelance clients in a professional, organized, and repeatable way — so nothing falls through the cracks and you look great from day one.

## What's Included

1. **`01-client-onboarding-checklist.md`** — A step-by-step checklist covering everything from pre-kickoff prep to ongoing project hygiene.
2. **`02-project-proposal-template.md`** — A ready-to-fill proposal template covering scope, timeline, pricing, and terms.
3. **`03-invoice-template.md`** — A clean invoice layout in both Markdown and CSV formats.
4. **`04-client-intake-questionnaire.md`** — A questionnaire to send new clients before your kickoff call, so you walk in fully prepared.

## How to Use This Kit

1. **Start with the checklist** (`01`). Use it as your master task list for every new client — copy it into your project management tool (Notion, Trello, Asana) or just print it out.
2. **Send the intake questionnaire** (`04`) as soon as a client signs on. Their answers will inform your proposal and kickoff call agenda.
3. **Draft your proposal** using the template (`02`). Fill in the bracketed placeholders with your specific scope, timeline, and pricing.
4. **Invoice with confidence** using the template (`03`). Use the Markdown version for polished PDFs, or the CSV version to import into spreadsheet/accounting software.
5. **Customize everything.** These are starting points — adjust tone, branding, and structure to match your business and the client relationship.

## Tips for Best Results

- Keep a copy of each completed document per client in that client's project folder for easy reference.
- Revisit the checklist for every new client, even repeat clients — it prevents scope creep and miscommunication.
- Update the templates over time as you learn what works best for your niche and clients.

## Support

This is a self-serve digital product — there's no bundled support, but the templates are intentionally simple, editable Markdown/CSV files that work in any text editor, Notion, Google Docs, or Word.

Happy onboarding, and good luck with your freelance business!
