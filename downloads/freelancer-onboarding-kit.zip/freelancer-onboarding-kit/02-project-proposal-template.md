# Project Proposal Template

*Replace bracketed placeholders with your project details.*

---

## Proposal for [Client Name]

**Prepared by:** [Your Name / Business Name]
**Date:** [Date]
**Valid until:** [Expiration Date]

### 1. Project Overview
[A brief 2-3 sentence summary of the client's goal and how this project addresses it.]

### 2. Objectives
- [Objective 1]
- [Objective 2]
- [Objective 3]

### 3. Scope of Work
Describe exactly what is included:

| Deliverable | Description | Estimated Time |
|---|---|---|
| [Deliverable 1] | [Details] | [X hours/days] |
| [Deliverable 2] | [Details] | [X hours/days] |
| [Deliverable 3] | [Details] | [X hours/days] |

### 4. Out of Scope
Clearly state what is *not* included to avoid scope creep:
- [Item 1]
- [Item 2]

### 5. Timeline
| Milestone | Deliverable | Target Date |
|---|---|---|
| 1 | [Milestone description] | [Date] |
| 2 | [Milestone description] | [Date] |
| 3 | Final Delivery | [Date] |

### 6. Investment
| Item | Price |
|---|---|
| [Package/Service] | $[Amount] |
| [Optional Add-on] | $[Amount] |
| **Total** | **$[Total Amount]** |

**Payment Terms:** [e.g., 50% deposit to begin, 50% on completion. Net 15 on invoices.]

### 7. Revisions Policy
[e.g., This proposal includes up to 2 rounds of revisions per deliverable. Additional revisions billed at $[rate]/hour.]

### 8. Next Steps
1. Review and approve this proposal
2. Sign the agreement / return a signed copy
3. Submit deposit invoice payment
4. Kickoff call scheduled within [X] business days of payment

### 9. Acceptance

By signing below, both parties agree to the terms outlined in this proposal.

Client Signature: ______________________  Date: ___________

[Your Name/Business Name] Signature: ______________________  Date: ___________

---
*Part of the Freelancer Client Onboarding Kit*
