# Invoice Template

*Copy this table into a spreadsheet or CSV file, or use the raw CSV below.*

## Markdown Version

**Invoice #:** [INV-0001]
**Date Issued:** [Date]
**Due Date:** [Date]

**From:**
[Your Name / Business Name]
[Your Address]
[Your Email / Phone]

**Bill To:**
[Client Name]
[Client Company]
[Client Email]

| Description | Quantity | Rate | Amount |
|---|---|---|---|
| [Service/Deliverable 1] | [1] | $[Rate] | $[Amount] |
| [Service/Deliverable 2] | [1] | $[Rate] | $[Amount] |
| [Service/Deliverable 3] | [1] | $[Rate] | $[Amount] |

| | |
|---|---|
| **Subtotal** | $[Subtotal] |
| **Tax (if applicable)** | $[Tax Amount] |
| **Total Due** | **$[Total]** |

**Payment Methods:** [Bank transfer, PayPal, Stripe, etc.]
**Payment Terms:** [e.g., Due within 15 days of invoice date]
**Notes:** [Thank you note or late-fee policy]

---

## CSV Version (copy below into invoice.csv)

```csv
Invoice Number,INV-0001
Date Issued,[Date]
Due Date,[Date]
From,[Your Name / Business Name]
Bill To,[Client Name]

Description,Quantity,Rate,Amount
[Service/Deliverable 1],1,[Rate],[Amount]
[Service/Deliverable 2],1,[Rate],[Amount]
[Service/Deliverable 3],1,[Rate],[Amount]

Subtotal,,,[Subtotal]
Tax,,,[Tax Amount]
Total Due,,,[Total]
```

---
*Part of the Freelancer Client Onboarding Kit*
