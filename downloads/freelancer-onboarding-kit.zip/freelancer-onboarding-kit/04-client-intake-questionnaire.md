# Client Intake Questionnaire

*Send this to new clients right after they sign on, before the kickoff call.*

## Contact Information
1. Full name:
2. Company/business name:
3. Best email for project communication:
4. Best phone number (optional):
5. Preferred communication method (email, Slack, phone, other):
6. Time zone:

## Project Basics
7. In one or two sentences, what problem are we solving with this project?
8. What does success look like for you at the end of this project?
9. Is there a hard deadline? If so, what is it and why?
10. What is your approved budget range for this project?

## Background
11. Do you have any existing brand guidelines, style guides, or assets to share?
12. Are there examples of work (yours or competitors') that you like or want to avoid?
13. Has this project been attempted before (internally or with another freelancer/agency)? If so, what happened?

## Stakeholders & Access
14. Who else is involved in decision-making or approvals for this project?
15. Who will provide feedback, and how quickly can we expect responses (typically)?
16. What tools/accounts will I need access to (e.g., website, CMS, analytics, design files)?

## Logistics
17. How often would you like status updates? (daily, weekly, at milestones)
18. Do you prefer scheduled check-in calls or async updates?
19. What is your preferred invoicing/payment schedule?

## Anything Else
20. Is there anything else about your business, audience, or goals that would help us do great work for you?

---
*Part of the Freelancer Client Onboarding Kit*
