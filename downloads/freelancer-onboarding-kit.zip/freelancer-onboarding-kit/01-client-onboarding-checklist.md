# Client Onboarding Checklist

Use this checklist to onboard every new client smoothly and professionally.

## 1. Before the Kickoff Call
- [ ] Send a welcome email confirming the project start date
- [ ] Share the signed proposal/contract and invoice schedule
- [ ] Send the Client Intake Questionnaire (see `04-client-intake-questionnaire.md`)
- [ ] Add client to your project management / communication tools
- [ ] Create a shared folder (Google Drive, Dropbox, etc.) for files and assets

## 2. Kickoff Call
- [ ] Confirm project scope, deliverables, and timeline
- [ ] Review payment terms and due dates
- [ ] Agree on primary communication channel (email, Slack, etc.)
- [ ] Agree on response time expectations (e.g., 24-48 business hours)
- [ ] Identify key stakeholders and decision-makers
- [ ] Set up recurring check-in schedule (weekly/bi-weekly)

## 3. Administrative Setup
- [ ] Collect billing details and preferred payment method
- [ ] Send/confirm first invoice or deposit request
- [ ] Add key dates to your calendar (milestones, deadlines, check-ins)
- [ ] Set up a project tracker (Trello, Notion, Asana, spreadsheet, etc.)

## 4. Access & Assets
- [ ] Request necessary logins, credentials, or API keys
- [ ] Request brand assets (logo, style guide, existing content)
- [ ] Confirm access to any third-party tools needed for the project

## 5. Kickoff Wrap-Up
- [ ] Send a recap email summarizing decisions made on the call
- [ ] Share the project timeline/roadmap with the client
- [ ] Set the date for the first milestone check-in

## 6. Ongoing Project Hygiene
- [ ] Log all scope changes in writing
- [ ] Keep an updated status log/report for the client
- [ ] Track hours/deliverables against the proposal
- [ ] Send invoices on schedule

---
*Part of the Freelancer Client Onboarding Kit*
